(function() {
  var AtomLiveServer, CompositeDisposable, allowUnsafeEval, liveServer, path;

  CompositeDisposable = require('atom').CompositeDisposable;

  allowUnsafeEval = require('loophole').allowUnsafeEval;

  path = require('path');

  liveServer = allowUnsafeEval(function() {
    return require("../live-server");
  });

  module.exports = AtomLiveServer = {
    subscriptions: null,
    activate: function(state) {
      this.subscriptions = new CompositeDisposable;
      return this.subscriptions.add(atom.commands.add('atom-workspace', {
        'atom-live-server:start-3000': (function(_this) {
          return function() {
            return _this.startServer(3000);
          };
        })(this),
        'atom-live-server:start-4000': (function(_this) {
          return function() {
            return _this.startServer(4000);
          };
        })(this),
        'atom-live-server:start-5000': (function(_this) {
          return function() {
            return _this.startServer(5000);
          };
        })(this),
        'atom-live-server:start-8000': (function(_this) {
          return function() {
            return _this.startServer(8000);
          };
        })(this),
        'atom-live-server:start-9000': (function(_this) {
          return function() {
            return _this.startServer(9000);
          };
        })(this)
      }));
    },
    deactivate: function() {
      return this.subscriptions.dispose();
    },
    serialize: function() {},
    getPaths: function() {
      var activeProjectPath, file, filePath, paneItem, projectPaths, ref;
      paneItem = atom.workspace.getActivePaneItem();
      file = paneItem != null ? (ref = paneItem.buffer) != null ? ref.file : void 0 : void 0;
      filePath = file != null ? file.path : void 0;
      projectPaths = atom.project.getPaths();
      activeProjectPath = null;
      if (filePath) {
        projectPaths.forEach(function(projectPath) {
          if (filePath.indexOf(projectPath) !== -1) {
            return activeProjectPath = projectPath;
          }
        });
      } else {
        activeProjectPath = projectPaths[0];
        filePath = "";
      }
      return activeProjectPath;
    },
    startServer: function(port) {
      var params, projectPath;
      projectPath = this.getPaths();
      if (!projectPath) {
        atom.notifications.addWarning("[Live Server] You haven't opened a Project, you must open one.");
        return;
      }
      params = {
        port: port,
        root: projectPath,
        open: true
      };
      return allowUnsafeEval(function() {
        return liveServer.start(params);
      });
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvcnVoamFhbi8uYXRvbS9wYWNrYWdlcy9hdG9tLWxpdmUtc2VydmVyL2xpYi9hdG9tLWxpdmUtc2VydmVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUMsc0JBQXVCLE9BQUEsQ0FBUSxNQUFSOztFQUN2QixrQkFBbUIsT0FBQSxDQUFRLFVBQVI7O0VBQ3BCLElBQUEsR0FBTyxPQUFBLENBQVEsTUFBUjs7RUFNUCxVQUFBLEdBQWMsZUFBQSxDQUFnQixTQUFBO1dBQUcsT0FBQSxDQUFRLGdCQUFSO0VBQUgsQ0FBaEI7O0VBR2QsTUFBTSxDQUFDLE9BQVAsR0FBaUIsY0FBQSxHQUNmO0lBQUEsYUFBQSxFQUFlLElBQWY7SUFFQSxRQUFBLEVBQVUsU0FBQyxLQUFEO01BQ1IsSUFBQyxDQUFBLGFBQUQsR0FBaUIsSUFBSTthQUNyQixJQUFDLENBQUEsYUFBYSxDQUFDLEdBQWYsQ0FBbUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFkLENBQWtCLGdCQUFsQixFQUFvQztRQUNyRCw2QkFBQSxFQUErQixDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUFHLEtBQUMsQ0FBQSxXQUFELENBQWEsSUFBYjtVQUFIO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQURzQjtRQUVyRCw2QkFBQSxFQUErQixDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUFHLEtBQUMsQ0FBQSxXQUFELENBQWEsSUFBYjtVQUFIO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUZzQjtRQUdyRCw2QkFBQSxFQUErQixDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUFHLEtBQUMsQ0FBQSxXQUFELENBQWEsSUFBYjtVQUFIO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUhzQjtRQUlyRCw2QkFBQSxFQUErQixDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUFHLEtBQUMsQ0FBQSxXQUFELENBQWEsSUFBYjtVQUFIO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUpzQjtRQUtyRCw2QkFBQSxFQUErQixDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUFHLEtBQUMsQ0FBQSxXQUFELENBQWEsSUFBYjtVQUFIO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUxzQjtPQUFwQyxDQUFuQjtJQUZRLENBRlY7SUFZQSxVQUFBLEVBQVksU0FBQTthQUNWLElBQUMsQ0FBQSxhQUFhLENBQUMsT0FBZixDQUFBO0lBRFUsQ0FaWjtJQWVBLFNBQUEsRUFBVyxTQUFBLEdBQUEsQ0FmWDtJQWlCQSxRQUFBLEVBQVUsU0FBQTtBQUNSLFVBQUE7TUFBQSxRQUFBLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBZixDQUFBO01BQ1gsSUFBQSwyREFBdUIsQ0FBRTtNQUN6QixRQUFBLGtCQUFXLElBQUksQ0FBRTtNQUVqQixZQUFBLEdBQWUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFiLENBQUE7TUFDZixpQkFBQSxHQUFvQjtNQUVwQixJQUFHLFFBQUg7UUFDRSxZQUFZLENBQUMsT0FBYixDQUFxQixTQUFDLFdBQUQ7VUFDbkIsSUFBRyxRQUFRLENBQUMsT0FBVCxDQUFpQixXQUFqQixDQUFBLEtBQW1DLENBQUMsQ0FBdkM7bUJBQ0UsaUJBQUEsR0FBb0IsWUFEdEI7O1FBRG1CLENBQXJCLEVBREY7T0FBQSxNQUFBO1FBTUUsaUJBQUEsR0FBb0IsWUFBYSxDQUFBLENBQUE7UUFDakMsUUFBQSxHQUFXLEdBUGI7O0FBU0EsYUFBTztJQWpCQyxDQWpCVjtJQW9DQSxXQUFBLEVBQWEsU0FBQyxJQUFEO0FBQ1gsVUFBQTtNQUFBLFdBQUEsR0FBYyxJQUFDLENBQUEsUUFBRCxDQUFBO01BRWQsSUFBRyxDQUFDLFdBQUo7UUFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQW5CLENBQThCLGdFQUE5QjtBQUNBLGVBRkY7O01BSUEsTUFBQSxHQUFTO1FBQ1AsSUFBQSxFQUFNLElBREM7UUFFUCxJQUFBLEVBQU0sV0FGQztRQUdQLElBQUEsRUFBTSxJQUhDOzthQU1ULGVBQUEsQ0FBZ0IsU0FBQTtlQUFHLFVBQVUsQ0FBQyxLQUFYLENBQWlCLE1BQWpCO01BQUgsQ0FBaEI7SUFiVyxDQXBDYjs7QUFaRiIsInNvdXJjZXNDb250ZW50IjpbIntDb21wb3NpdGVEaXNwb3NhYmxlfSA9IHJlcXVpcmUgJ2F0b20nXG57YWxsb3dVbnNhZmVFdmFsfSA9IHJlcXVpcmUgJ2xvb3Bob2xlJ1xucGF0aCA9IHJlcXVpcmUgJ3BhdGgnXG5cbiMgSSBtb2RpZmllZFxuIyBsaXZlLXNhdmVyL25vZGVfbW9kdWxlcy9jb25uZWN0L25vZGVfbW9kdWxlcy9tb3JnYW4vaW5kZXguanNcbiMgYWRkIGxpbmUgMTI6IHZhciBGdW5jdGlvbiA9IHJlcXVpcmUoJ2xvb3Bob2xlJykuRnVuY3Rpb247XG4jIHRvIGxldCBpdCB3b3JrIGluIGF0b20uXG5saXZlU2VydmVyID0gIGFsbG93VW5zYWZlRXZhbCAtPiByZXF1aXJlIFwiLi4vbGl2ZS1zZXJ2ZXJcIlxuXG5cbm1vZHVsZS5leHBvcnRzID0gQXRvbUxpdmVTZXJ2ZXIgPVxuICBzdWJzY3JpcHRpb25zOiBudWxsXG5cbiAgYWN0aXZhdGU6IChzdGF0ZSkgLT5cbiAgICBAc3Vic2NyaXB0aW9ucyA9IG5ldyBDb21wb3NpdGVEaXNwb3NhYmxlXG4gICAgQHN1YnNjcmlwdGlvbnMuYWRkIGF0b20uY29tbWFuZHMuYWRkICdhdG9tLXdvcmtzcGFjZScsIHtcbiAgICAgICdhdG9tLWxpdmUtc2VydmVyOnN0YXJ0LTMwMDAnOiA9PiBAc3RhcnRTZXJ2ZXIoMzAwMCksXG4gICAgICAnYXRvbS1saXZlLXNlcnZlcjpzdGFydC00MDAwJzogPT4gQHN0YXJ0U2VydmVyKDQwMDApLFxuICAgICAgJ2F0b20tbGl2ZS1zZXJ2ZXI6c3RhcnQtNTAwMCc6ID0+IEBzdGFydFNlcnZlcig1MDAwKSxcbiAgICAgICdhdG9tLWxpdmUtc2VydmVyOnN0YXJ0LTgwMDAnOiA9PiBAc3RhcnRTZXJ2ZXIoODAwMCksXG4gICAgICAnYXRvbS1saXZlLXNlcnZlcjpzdGFydC05MDAwJzogPT4gQHN0YXJ0U2VydmVyKDkwMDApXG4gICAgfVxuXG4gIGRlYWN0aXZhdGU6IC0+XG4gICAgQHN1YnNjcmlwdGlvbnMuZGlzcG9zZSgpXG5cbiAgc2VyaWFsaXplOiAtPlxuXG4gIGdldFBhdGhzOiAtPlxuICAgIHBhbmVJdGVtID0gYXRvbS53b3Jrc3BhY2UuZ2V0QWN0aXZlUGFuZUl0ZW0oKVxuICAgIGZpbGUgPSBwYW5lSXRlbT8uYnVmZmVyPy5maWxlXG4gICAgZmlsZVBhdGggPSBmaWxlPy5wYXRoXG5cbiAgICBwcm9qZWN0UGF0aHMgPSBhdG9tLnByb2plY3QuZ2V0UGF0aHMoKVxuICAgIGFjdGl2ZVByb2plY3RQYXRoID0gbnVsbFxuXG4gICAgaWYgZmlsZVBhdGhcbiAgICAgIHByb2plY3RQYXRocy5mb3JFYWNoIChwcm9qZWN0UGF0aCkgLT5cbiAgICAgICAgaWYgZmlsZVBhdGguaW5kZXhPZihwcm9qZWN0UGF0aCkgaXNudCAtMVxuICAgICAgICAgIGFjdGl2ZVByb2plY3RQYXRoID0gcHJvamVjdFBhdGhcblxuICAgIGVsc2VcbiAgICAgIGFjdGl2ZVByb2plY3RQYXRoID0gcHJvamVjdFBhdGhzWzBdXG4gICAgICBmaWxlUGF0aCA9IFwiXCJcblxuICAgIHJldHVybiBhY3RpdmVQcm9qZWN0UGF0aFxuXG4gIHN0YXJ0U2VydmVyOiAocG9ydCkgLT5cbiAgICBwcm9qZWN0UGF0aCA9IEBnZXRQYXRocygpXG5cbiAgICBpZiAhcHJvamVjdFBhdGhcbiAgICAgIGF0b20ubm90aWZpY2F0aW9ucy5hZGRXYXJuaW5nIFwiW0xpdmUgU2VydmVyXSBZb3UgaGF2ZW4ndCBvcGVuZWQgYSBQcm9qZWN0LCB5b3UgbXVzdCBvcGVuIG9uZS5cIlxuICAgICAgcmV0dXJuXG5cbiAgICBwYXJhbXMgPSB7XG4gICAgICBwb3J0OiBwb3J0LFxuICAgICAgcm9vdDogcHJvamVjdFBhdGgsXG4gICAgICBvcGVuOiB0cnVlXG4gICAgfTtcblxuICAgIGFsbG93VW5zYWZlRXZhbCAtPiBsaXZlU2VydmVyLnN0YXJ0IHBhcmFtcztcbiJdfQ==
