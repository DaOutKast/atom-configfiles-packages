# atom-live-server package

Launch a simple development http server with live reload capability.

![Demo](https://raw.githubusercontent.com/jas-chen/atom-live-server/master/doc/demo.gif)

This package is based on awesome [Live Server](https://github.com/tapio/live-server) project.

## Usage

`ctrl-shift-3` launch live server on port 3000.

`ctrl-shift-4` launch live server on port 4000.

`ctrl-shift-5` launch live server on port 5000.

`ctrl-shift-8` launch live server on port 8000.

`ctrl-shift-9` launch live server on port 9000.
